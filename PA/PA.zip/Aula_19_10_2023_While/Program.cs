﻿using System;

namespace Aula_19_10_2023_While
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
